class eSpeak
{
public:
	eSpeak();
	void lang(const char *lang);
	void speak(const char *word);
	~eSpeak();
};
