var searchData=
[
  ['qisr_2eh',['qisr.h',['../qisr_8h.html',1,'']]],
  ['qisraudiowrite',['QISRAudioWrite',['../qisr_8h.html#a47fd2588fe834fa2d51fef1961d7aef4',1,'qisr.h']]],
  ['qisrgetparam',['QISRGetParam',['../qisr_8h.html#a2081e3cad9a8155c15790a2476be7044',1,'qisr.h']]],
  ['qisrgetresult',['QISRGetResult',['../qisr_8h.html#a2e7880db4792266a4d1439238c0b2c1b',1,'qisr.h']]],
  ['qisrsessionbegin',['QISRSessionBegin',['../qisr_8h.html#aaec4a5779275e07c4f7405ed8d739416',1,'qisr.h']]],
  ['qisrsessionend',['QISRSessionEnd',['../qisr_8h.html#ab50c4114e032100c4093ddd51329fecc',1,'qisr.h']]],
  ['qtts_2eh',['qtts.h',['../qtts_8h.html',1,'']]],
  ['qttsaudioget',['QTTSAudioGet',['../qtts_8h.html#a4e4f6bed4b9e4ea553aa00ccf539c22a',1,'qtts.h']]],
  ['qttsgetparam',['QTTSGetParam',['../qtts_8h.html#a0812612ff738a828490e4e3db59767e8',1,'qtts.h']]],
  ['qttssessionbegin',['QTTSSessionBegin',['../qtts_8h.html#a3fba4ad9599445073335851cc9479542',1,'qtts.h']]],
  ['qttssessionend',['QTTSSessionEnd',['../qtts_8h.html#a75d5047a2a889dbd890d116a6d0b550a',1,'qtts.h']]],
  ['qttstextput',['QTTSTextPut',['../qtts_8h.html#a5b7d146d6a35341d4d73efd720ae987b',1,'qtts.h']]]
];
